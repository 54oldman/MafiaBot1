(function () {
  const tg = window.tg;

  const playerNameEl = document.getElementById("playerName");
  const gameStatusEl = document.getElementById("gameStatus");
  const sendReadyBtn = document.getElementById("sendReadyBtn");
  const voteBtn = document.getElementById("voteBtn");

  const roleBlock = document.getElementById("roleBlock");
  const roleNameEl = document.getElementById("roleName");
  const roleDescEl = document.getElementById("roleDesc");

  const playersBlock = document.getElementById("playersBlock");
  const playersCountEl = document.getElementById("playersCount");
  const playersListEl = document.getElementById("playersList");

  const phasePillEl = document.getElementById("phasePill");

  const NIGHT_ACTION_BTN_ID = "nightActionBtn";
  let nightActionBtn = document.getElementById(NIGHT_ACTION_BTN_ID);

  // Если кнопки ещё нет в html — создадим её программно под кнопкой голосования
  if (!nightActionBtn) {
    const actionsContainer = sendReadyBtn.parentElement;
    nightActionBtn = document.createElement("button");
    nightActionBtn.id = NIGHT_ACTION_BTN_ID;
    nightActionBtn.className = "btn btn--secondary";
    nightActionBtn.style.marginTop = "8px";
    nightActionBtn.textContent = "Сделать ночное действие";
    nightActionBtn.disabled = true;
    actionsContainer.appendChild(nightActionBtn);
  }

  const SPECIAL_ROLES = ["mafia", "don", "maniac", "sheriff", "doctor", "lawyer"];

  const ROLE_DEFS = {
    mafia: {
      key: "mafia",
      name: "Мафия",
      description:
        "Ночью убиваешь мирных жителей, днём притворяешься простым горожанином.",
    },
    don: {
      key: "don",
      name: "Дон",
      description:
        "Глава мафии. Может выбрать окончательную цель для убийства ночью.",
    },
    maniac: {
      key: "maniac",
      name: "Маньяк",
      description:
        "Одиночный игрок. Каждую ночь убивает любого игрока и стремится остаться последним.",
    },
    sheriff: {
      key: "sheriff",
      name: "Комиссар",
      description:
        "Ночью проверяешь игроков и узнаёшь, являются ли они мафией.",
    },
    doctor: {
      key: "doctor",
      name: "Доктор",
      description:
        "Ночью можешь спасти одного игрока от убийства.",
    },
    lawyer: {
      key: "lawyer",
      name: "Адвокат",
      description:
        "Ночью может защитить одного игрока от убийства, обеспечив ему алиби.",
    },
    citizen: {
      key: "citizen",
      name: "Мирный житель",
      description:
        "У тебя нет специальных способностей. Днём обсуждаешь и голосуешь против подозреваемых.",
    },
  };

  const state = {
    user: null,
    role: null,         // роль текущего игрока (ROLE_DEFS[…])
    players: [],        // {id, name, alive, isYou, roleKey}
    phase: "lobby",     // 'lobby' | 'day' | 'night' | 'results' | 'game_over'
    dayNumber: 1,
    selectedTargetId: null, // используется и днём, и ночью как выбранная цель
    hasVoted: false,
    winner: null,       // 'mafia' | 'town' | 'maniac' | null
  };

  // ==== УТИЛИТЫ ====
  function getDisplayName(user) {
    if (!user) return "Неизвестный игрок";
    const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ");
    if (fullName) return fullName;
    if (user.username) return "@" + user.username;
    return "Игрок #" + user.id;
  }

  function shuffleArray(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
  }

  function randomChoice(arr) {
    if (!arr || arr.length === 0) return null;
    const idx = Math.floor(Math.random() * arr.length);
    return arr[idx];
  }

  function getAlivePlayers() {
    return state.players.filter((p) => p.alive);
  }

  function getPlayerById(id) {
    return state.players.find((p) => p.id === id) || null;
  }

  // ==== ФАЗЫ ====

  function renderPhase() {
    if (!phasePillEl) return;
    phasePillEl.className = "phase-pill";

    let text = "";
    let extraClass = "";

    switch (state.phase) {
      case "lobby":
        text = "Подготовка";
        extraClass = "phase-pill--lobby";
        break;
      case "day":
        text = "День " + state.dayNumber;
        extraClass = "phase-pill--day";
        break;
      case "night":
        text = "Ночь";
        extraClass = "phase-pill--night";
        break;
      case "results":
        text = "Результаты";
        extraClass = "phase-pill--results";
        break;
      case "game_over":
        text = "Игра окончена";
        extraClass = "phase-pill--results";
        break;
      default:
        text = "Неизвестно";
        extraClass = "phase-pill--lobby";
    }

    phasePillEl.textContent = text;
    phasePillEl.classList.add(extraClass);
  }

  function setPhase(newPhase) {
    state.phase = newPhase;
    renderPhase();
    updateVoteButtonState();
    updateNightActionButtonState();
  }

  // ==== ЮЗЕР / TELEGRAM ====

  function initUser() {
    const user = tg && tg.initDataUnsafe ? tg.initDataUnsafe.user : null;
    state.user = user;

    const displayName = getDisplayName(user);
    playerNameEl.textContent = displayName;

    if (!user) {
      gameStatusEl.innerHTML =
        "<p>Не удалось получить данные пользователя.</p><p class='small-muted'>Открой мини-приложение через Telegram-бота, чтобы авторизоваться.</p>";
      sendReadyBtn.disabled = true;
      if (voteBtn) voteBtn.disabled = true;
      if (nightActionBtn) nightActionBtn.disabled = true;
    }
  }

  function setupMainButton() {
    if (!tg || !tg.MainButton) return;

    try {
      tg.MainButton.setText("Готов играть");
      tg.MainButton.show();
      tg.MainButton.onClick(function () {
        sendReady("main_button");
      });
    } catch (e) {
      console.warn("MainButton error:", e);
    }
  }

  // ==== РОЛЬ И ИГРОКИ ====

  function renderRole(role) {
    if (!role) {
      roleBlock.classList.add("hidden");
      return;
    }

    roleBlock.classList.remove("hidden");
    roleNameEl.textContent = role.name;
    roleDescEl.textContent = role.description;

    roleNameEl.className = "role-pill";

    let pillClass = "role-pill--neutral";

    switch (role.key) {
      case "mafia":
      case "don":
        pillClass = "role-pill--mafia";
        break;
      case "maniac":
        pillClass = "role-pill--maniac";
        break;
      case "sheriff":
        pillClass = "role-pill--sheriff";
        break;
      case "doctor":
        pillClass = "role-pill--doctor";
        break;
      case "lawyer":
        pillClass = "role-pill--lawyer";
        break;
      default:
        pillClass = "role-pill--neutral";
    }

    roleNameEl.classList.add(pillClass);
  }

  function renderPlayers(players) {
    if (!players || !players.length) {
      playersBlock.classList.add("hidden");
      return;
    }

    playersBlock.classList.remove("hidden");
    playersCountEl.textContent = players.length + " чел.";
    playersListEl.innerHTML = "";

    players.forEach((p) => {
      const li = document.createElement("li");
      li.className = "players-list-item";

      const left = document.createElement("div");
      left.className = "player-name-main";

      const nameSpan = document.createElement("span");
      nameSpan.textContent = p.name;
      left.appendChild(nameSpan);

      if (p.isYou) {
        const youTag = document.createElement("span");
        youTag.className = "player-tag-you";
        youTag.textContent = "ты";
        left.appendChild(youTag);
      }

      const right = document.createElement("div");
      right.className = "player-status";

      if (p.alive) {
        right.classList.add("player-status--alive");
        right.textContent = "жив";
      } else {
        right.classList.add("player-status--dead");
        right.textContent = "мертв";
      }

      // кликабельность: днём для голосования, ночью для ночного действия
      const canSelectDay =
        p.alive && !p.isYou && !state.hasVoted && state.phase === "day";
      const canSelectNight =
        p.alive &&
        !p.isYou &&
        state.phase === "night" &&
        roleHasNightTarget(state.role);

      if (canSelectDay || canSelectNight) {
        li.classList.add("players-list-item--selectable");
        li.addEventListener("click", function () {
          setSelectedTarget(p.id);
        });
      }

      if (state.selectedTargetId === p.id) {
        li.classList.add("players-list-item--selected");
      }

      li.appendChild(left);
      li.appendChild(right);
      playersListEl.appendChild(li);
    });

    updateVoteButtonState();
    updateNightActionButtonState();
  }

  function setSelectedTarget(playerId) {
    if (state.selectedTargetId === playerId) {
      state.selectedTargetId = null;
    } else {
      state.selectedTargetId = playerId;
    }
    renderPlayers(state.players);
  }

  function roleHasNightTarget(role) {
    if (!role) return false;
    return ["mafia", "don", "maniac", "sheriff", "doctor", "lawyer"].includes(
      role.key
    );
  }

  // ==== ОТПРАВКА ДАННЫХ В БОТА ====

  function sendReady(source) {
    if (!state.user || !tg || !tg.sendData) {
      simulateGameStart();
      sendReadyBtn.style.display = "none";
      return;
    }

    const payload = {
      type: "player_ready",
      source: source,
      user: {
        id: state.user.id,
        username: state.user.username,
        first_name: state.user.first_name,
        last_name: state.user.last_name,
        language_code: state.user.language_code,
      },
    };

    console.log("Отправка данных: ", payload);  // Логирование перед отправкой

    tg.sendData(JSON.stringify(payload));

    if (sendReadyBtn) {
      sendReadyBtn.style.display = "none";
    }

    if (tg.MainButton) {
      try {
        tg.MainButton.hide();
      } catch (e) {
        console.warn("MainButton.hide error:", e);
      }
    }

    simulateGameStart();
  }

  function sendVote() {
    if (!state.user || !state.selectedTargetId) return;

    if (tg && tg.sendData) {
      const payload = {
        type: "vote",
        voter_id: state.user.id,
        target_id: state.selectedTargetId,
      };
      tg.sendData(JSON.stringify(payload));
    }

    state.hasVoted = true;
    updateVoteButtonState();

    simulateVotingResults();
  }

  function sendNightAction() {
    if (tg && tg.sendData && state.role && roleHasNightTarget(state.role)) {
      const payload = {
        type: "night_action",
        role: state.role.key,
        actor_id: state.user ? state.user.id : null,
        target_id: state.selectedTargetId || null,
      };
      tg.sendData(JSON.stringify(payload));
    }

    const actions = collectNightActions();
    resolveNight(actions);
  }

  // ==== ИНИЦИАЛИЗАЦИЯ ====

  function initEvents() {
    sendReadyBtn.addEventListener("click", function () {
      sendReady("button");
    });

    voteBtn.addEventListener("click", function () {
      sendVote();
    });

    nightActionBtn.addEventListener("click", function () {
      sendNightAction();
    });
  }

  function init() {
    initUser();
    renderPhase();
    setupMainButton();
    initEvents();

    if (tg && typeof tg.ready === "function") {
      tg.ready();
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
