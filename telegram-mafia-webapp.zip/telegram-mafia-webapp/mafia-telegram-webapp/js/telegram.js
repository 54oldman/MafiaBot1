// telegram.js
// Обёртка над Telegram WebApp API с моками для разработки в обычном браузере.

(function () {
  function createMockWebApp() {
    const mockUser = {
      id: 123456789,
      first_name: "Тестовый",
      last_name: "Игрок",
      username: "test_player",
      language_code: "ru",
    };

    const mock = {
      initDataUnsafe: {
        user: mockUser,
      },

      ready() {
        console.log("[MockTelegram] ready()");
      },

      sendData(data) {
        console.log("[MockTelegram] sendData:", data);
      },

      MainButton: {
        _handler: null,

        show() {
          console.log("[MockTelegram] MainButton.show()");
        },
        hide() {
          console.log("[MockTelegram] MainButton.hide()");
        },
        setText(text) {
          console.log("[MockTelegram] MainButton.setText:", text);
        },
        onClick(handler) {
          console.log("[MockTelegram] MainButton.onClick(handler) (mock)");
          this._handler = handler;
          // Для отладки можно вызвать из консоли:
          // window.__mockMainButtonClick()
          window.__mockMainButtonClick = handler;
        },
      },
    };

    console.log(
      "%c[MockTelegram] Используется мок Telegram.WebApp (запуск не из Telegram).",
      "color: #38bdf8"
    );

    return mock;
  }

  let webApp;

  const hasRealWebApp =
    window.Telegram &&
    window.Telegram.WebApp &&
    window.Telegram.WebApp.initDataUnsafe &&
    window.Telegram.WebApp.initDataUnsafe.user;

  if (hasRealWebApp) {
    // Настоящее мини-приложение внутри Telegram
    webApp = window.Telegram.WebApp;

    try {
      // растянуть WebApp по высоте
      if (typeof webApp.expand === "function") {
        webApp.expand();
      }

      if (typeof webApp.disableVerticalSwipes === "function") {
        webApp.disableVerticalSwipes();
      }

      if (typeof webApp.ready === "function") {
        webApp.ready();
      }

      console.log(
        "[Telegram] WebApp режим, пользователь:",
        webApp.initDataUnsafe.user
      );
    } catch (e) {
      console.warn("Telegram.WebApp init error:", e);
    }
  } else {
    // Обычный браузер — используем мок
    webApp = createMockWebApp();
  }

  // Делаем доступным в app.js как window.tg
  window.tg = webApp;
})();
