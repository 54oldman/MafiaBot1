# Mafia Telegram WebApp

Небольшое веб-приложение (HTML/CSS/JS) для игры в мафию внутри Telegram Mini Apps.

## Структура

- `index.html` — основной файл приложения.
- `css/styles.css` — базовые стили.
- `js/telegram.js` — обёртка над Telegram WebApp API с моками для разработки в браузере.
- `js/app.js` — логика отображения имени игрока и кнопки "Я готов играть".

## Запуск в браузере (для разработки)

1. Открой `index.html` напрямую в браузере или через Live Server в VS Code.
2. Так как Telegram недоступен, будет использован мок в `telegram.js` — в консоли увидишь лог `[MockTelegram]`.

## Запуск в Telegram

1. Залей содержимое папки на хостинг с HTTPS.
2. В BotFather:
   - настрой Mini App (Main Mini App) на URL этого проекта;
   - или добавь кнопку Menu Button / web_app с этим URL.
3. При открытии через бота `window.Telegram.WebApp` будет доступен, и приложение возьмёт реальные данные пользователя из `initDataUnsafe.user`.
