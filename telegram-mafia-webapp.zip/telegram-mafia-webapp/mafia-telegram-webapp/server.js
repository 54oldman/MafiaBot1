// server.js
// Простой статический сервер без дополнительных пакетов.

const http = require("http");
const fs = require("fs");
const path = require("path");

const root = __dirname;
const PORT = 8080;

const server = http.createServer((req, res) => {
  let urlPath = req.url.split("?")[0];

  if (urlPath === "/" || urlPath === "") {
    urlPath = "/index.html";
  }

  const filePath = path.join(root, urlPath);

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.statusCode = 404;
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.end("Файл не найден");
      return;
    }

    let ext = path.extname(filePath).toLowerCase();
    let contentType = "text/html; charset=utf-8";

    if (ext === ".js") contentType = "text/javascript; charset=utf-8";
    if (ext === ".css") contentType = "text/css; charset=utf-8";

    res.statusCode = 200;
    res.setHeader("Content-Type", contentType);
    res.end(data);
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`🚀 Сервер запущен на http://127.0.0.1:${PORT}`);
});
