require("dotenv").config();
const { Telegraf, Markup } = require("telegraf");

const BOT_TOKEN = process.env.BOT_TOKEN;
const WEBAPP_URL = process.env.WEBAPP_URL;

if (!BOT_TOKEN) {
  console.error("❌ Нет BOT_TOKEN в .env");
  process.exit(1);
}

if (!WEBAPP_URL) {
  console.warn(
    "⚠️ Нет WEBAPP_URL в .env — кнопка WebApp не будет работать корректно"
  );
}

const bot = new Telegraf(BOT_TOKEN);

// /start — отправляем СООБЩЕНИЕ с inline-кнопкой WebApp
bot.start((ctx) => {
  if (!WEBAPP_URL) {
    return ctx.reply(
      "Привет! WEBAPP_URL пока не настроен. Добавь его в .env."
    );
  }

  return ctx.reply(
    "Привет! Нажми кнопку ниже, чтобы открыть игру в мафию 👇",
    {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "Играть в мафию",
              web_app: { url: WEBAPP_URL },
            },
          ],
        ],
      },
    }
  );
});

// Ловим данные, пришедшие из WebApp через Telegram.WebApp.sendData
bot.on("message", (ctx) => {
  const webAppData = ctx.message.web_app_data;

  if (!webAppData) {
    // обычное сообщение (текст, стикер и т.п.) — можно игнорировать
    return;
  }

  console.log("=== ПРИШЛО ИЗ WEBAPP ===");
  console.log("raw:", webAppData);

  let data;
  try {
    data = JSON.parse(webAppData.data);
  } catch (e) {
    console.error("Ошибка парсинга web_app_data.data:", e);
    return;
  }

  console.log("parsed:", data);

  if (data.type === "player_ready") {
    const name =
      data.user.first_name || data.user.username || `id ${data.user.id}`;
    ctx.reply(`Игрок ${name} готов к игре ✅`);
  }

  if (data.type === "vote") {
    ctx.reply(
      `Голос принят: ${data.voter_id} против ${data.target_id} 🗳`
    );
  }

  if (data.type === "night_action") {
    ctx.reply(
      `Ночное действие: роль ${data.role}, цель: ${
        data.target_id || "не выбрана"
      } 🌙`
    );
  }
});

bot.launch();
console.log("🤖 Бот запущен.");

// Красивое завершение
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
